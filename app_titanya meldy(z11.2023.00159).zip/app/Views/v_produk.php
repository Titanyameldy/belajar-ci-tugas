<?= $this->extend('layout') ?>
<?= $this->section('content') ?>
Ini halaman produk
<?= $this->endSection() ?>